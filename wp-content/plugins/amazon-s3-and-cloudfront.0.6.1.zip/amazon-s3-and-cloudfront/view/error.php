<div class="aws-content as3cf-error">

	<div class="error">
		<p><?php echo $error->get_error_message(); ?></p>
	</div>

</div>