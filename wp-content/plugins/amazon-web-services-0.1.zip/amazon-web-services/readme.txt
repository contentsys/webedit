=== Amazon Web Services ===
Contributors: bradt
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=5VPMGLLK94XJC
Tags: amazon, amazon web services
Requires at least: 3.5
Tested up to: 3.6.1
Stable tag: 0.1
License: GPLv3

Houses the Amazon Web Services (AWS) PHP libraries and manages access keys. Required by other AWS plugins.

== Description ==

This plugin is required by other plugins, which uses its libraries and its settings to connect to AWS services. Currently, there is only one plugin that requires this plugin:

* [Amazon S3 and CloudFront](http://wordpress.org/plugins/amazon-s3-and-cloudfront/)

== Installation ==

1. Use WordPress' built-in installer
2. A new AWS menu will appear in the side menu

== Screenshots ==

1. Settings screen

== Changelog ==

= 0.1 - 2013-09-20 =
* First release