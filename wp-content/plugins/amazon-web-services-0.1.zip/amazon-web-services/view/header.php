<div class="wrap aws-main">

	<div id="icon-amazon-web-services" class="icon32"><br /></div><h2><?php echo ( isset( $page_title ) ) ? $page_title : __( 'Amazon Web Services', 'amazon-web-services' ); ?></h2>
